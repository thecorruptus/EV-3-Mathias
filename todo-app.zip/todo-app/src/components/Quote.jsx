import { useEffect, useState } from "react";

function Quote() {
  const [quote, setQuote] = useState(null);

  useEffect(() => {
    fetch("https://api.quotable.io/random")
      .then((res) => {
        if (!res.ok) {
          throw new Error("Error al obtener la frase");
        }
        return res.json();
      })
      .then((data) => setQuote(data))
      .catch((error) => {
        console.error("Error al cargar frase:", error);
      });
  }, []);

  if (!quote) return <p>Cargando frase motivacional...</p>;

  return (
    <div style={{ marginBottom: "1.5rem", textAlign: "center" }}>
      <blockquote style={{ fontStyle: "italic", color: "#9ca3af" }}>
        “{quote.content}”
      </blockquote>
      <p style={{ fontWeight: "bold", color: "#10b981" }}>— {quote.author}</p>
    </div>
  );
}

export default Quote;

import { useState, useEffect, useRef } from "react";
import TaskForm from "./components/TaskForm";
import TaskList from "./components/TaskList";
import "./App.css";

function App() {
  const [tasks, setTasks] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [theme, setTheme] = useState("dark");
  const hasMounted = useRef(false);

  // Cargar tareas desde localStorage
  useEffect(() => {
    const stored = localStorage.getItem("tasks");
    if (stored) {
      setTasks(JSON.parse(stored));
    }
  }, []);

  // Guardar tareas solo después de que se montó la app
  useEffect(() => {
    if (hasMounted.current) {
      localStorage.setItem("tasks", JSON.stringify(tasks));
    } else {
      hasMounted.current = true;
    }
  }, [tasks]);

  // Cambiar clase de body para el modo claro/oscuro
  useEffect(() => {
    document.body.className = theme;
  }, [theme]);

  const addTask = (task) => {
    setTasks([...tasks, task]);
  };

  const updateTask = (updatedTask) => {
    setTasks(
      tasks.map((task) =>
        task.id === updatedTask.id ? updatedTask : task
      )
    );
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter((task) => task.id !== id));
  };

  const filteredTasks = tasks.filter((task) =>
    task.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const toggleTheme = () => {
    setTheme((prev) => (prev === "dark" ? "light" : "dark"));
  };

  const exportJSON = () => {
    const dataStr = JSON.stringify(tasks, null, 2);
    const blob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "tareas.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="container">
      <h1>📝 ToDo List Pro</h1>

      <div className="task-controls">
        <button className="theme-toggle" onClick={toggleTheme}>
          Cambiar a modo {theme === "dark" ? "claro" : "oscuro"}
        </button>
        <button className="export-btn" onClick={exportJSON}>
          Exportar JSON
        </button>
        <div style={{ marginTop: "1rem" }}>
          <input
            type="text"
            placeholder="Buscar tareas por nombre..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{ padding: "0.5rem", width: "300px", borderRadius: "8px" }}
          />
        </div>
        <p style={{ marginTop: "1rem" }}>
          Tareas activas: <strong>{filteredTasks.length}</strong>
        </p>
      </div>

      <TaskForm addTask={addTask} />
      <TaskList
        tasks={filteredTasks}
        deleteTask={deleteTask}
        updateTask={updateTask}
      />
    </div>
  );
}

export default App;

import TaskItem from "./TaskItem";

// Lista de todas las tareas
function TaskList({ tasks, deleteTask, updateTask }) {
  if (tasks.length === 0) {
    return <p>No hay tareas aún.</p>;
  }

  return (
    <div className="task-list">
      {tasks.map((task) => (
        <TaskItem
          key={task.id}
          task={task}
          deleteTask={deleteTask}
          updateTask={updateTask}
        />
      ))}
    </div>
  );
}

export default TaskList;
